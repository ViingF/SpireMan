
#ifndef SPIRELIKE_CHARACTERSELECTSCENE_HPP
#define SPIRELIKE_CHARACTERSELECTSCENE_HPP

#include "core/Scene.hpp"
#include "core/GameContext.hpp"
#include "core/SceneTransition.hpp"

#include "ui/Button.hpp"

#include <SFML/Graphics.hpp>

class CharacterSelectScene : public Scene {
public:
    explicit CharacterSelectScene(
        GameContext& context
    );

    void handleEvent(
        const sf::Event& event,
        const sf::RenderWindow& window
    ) override;

    void update(float dt) override;

    void draw(sf::RenderWindow& window) override;

    SceneTransition getTransition() const override;
    void resetTransition() override;


private:
    Button ironcladButton;
    sf::RectangleShape ironcladPortrait;

    sf::RectangleShape lockedButtons[3];

    Button startButton;
    Button backButton;

    bool ironcladSelected = true;

    SceneTransition transition;

};

#endif //SPIRELIKE_CHARACTERSELECTSCENE_HPP