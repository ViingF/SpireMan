#include "ShopScene.hpp"

#include "config/Constants.hpp"

#include <algorithm>
#include <iostream>
#include <sstream>
#include <string>

#include "ui/TextUtils.hpp"
#include "ui/TopInfoBar.hpp"

namespace {

bool readLeftClickPosition(
    const sf::Event& event,
    sf::Vector2i& pixelPosition
)
{
    if (const auto* mouse =
            event.getIf<sf::Event::MouseButtonPressed>()) {
        if (mouse->button == sf::Mouse::Button::Left) {
            pixelPosition = mouse->position;
            return true;
        }
    }

    return false;
}

}

ShopScene::ShopScene(GameContext& context)
    : Scene(context),
      removeCardButton_(
          sf::Vector2f(1180.0f, 710.0f),
          sf::Vector2f(420.0f, 80.0f),
          context.resources.getFont("zh-R"),
          "Remove Card"
      ),
      leaveButton_(
          sf::Vector2f(1180.0f, 820.0f),
          sf::Vector2f(420.0f, 90.0f),
          context.resources.getFont("zh-R"),
          "Leave"
      ),
      cancelRemoveButton_(
          sf::Vector2f(1540.0f, 125.0f),
          sf::Vector2f(250.0f, 70.0f),
          context.resources.getFont("zh-R"),
          "Cancel"
      ),
      removePrevPageButton_(
          sf::Vector2f(620.0f, 930.0f),
          sf::Vector2f(210.0f, 70.0f),
          context.resources.getFont("zh-R"),
          "Previous"
      ),
      removeNextPageButton_(
          sf::Vector2f(1090.0f, 930.0f),
          sf::Vector2f(210.0f, 70.0f),
          context.resources.getFont("zh-R"),
          "Next"
          ),
    mapIconButton_(
        sf::Vector2f(0.0f, 0.0f),
        sf::Vector2f(64.0f, 64.0f),
        context.resources.getFont("zh-R"),
        ""
    )

{
    for (int i = 0; i < SHOP_CARD_COUNT; ++i) {
        CardId cardId =
            context.cards.chooseRandomRewardCardId(context.runState.rng);

        if (cardId != 0) {
            cardOffers_.push_back(cardId);
            sold_.push_back(false);
        }
    }
    mapIconButton_.setTexture(
    context.resources.getTexture("map")
);

}


void ShopScene::handleEvent(
    const sf::Event& event,
    const sf::RenderWindow& window
)
{
    shopView_.layoutButtons(
        mapIconButton_,
        removeCardButton_,
        leaveButton_,
        cancelRemoveButton_,
        removePrevPageButton_,
        removeNextPageButton_,
        window
    );

    if (transition_.target != SceneType::None) {
        return;
    }

    if (removingCard_) {
        if (removeCardScene_) {
            removeCardScene_->handleEvent(event, window);

            if (removeCardScene_->isFinished()) {
                finishRemoveCardFromScene();
            }
        }

        return;
    }


    mapIconButton_.handleEvent(event, window);

    if (mapIconButton_.wasClicked()) {
        context.audio.playSound("Click");
        transition_.openMapPreview = true;
        transition_.target = SceneType::Map;
        mapIconButton_.reset();
        return;
    }

    if (transition_.target != SceneType::None) {
        return;
    }

    if (removingCard_) {
        cancelRemoveButton_.handleEvent(event, window);
        removePrevPageButton_.handleEvent(event, window);
        removeNextPageButton_.handleEvent(event, window);

        if (cancelRemoveButton_.wasClicked()) {
            cancelRemoveButton_.reset();
            removingCard_ = false;
            message_ = "Card removal cancelled.";
            return;
        }

        if (removePrevPageButton_.wasClicked()) {
            removePrevPageButton_.reset();
            removePage_ -= 1;
            clampRemovePage();
            return;
        }

        if (removeNextPageButton_.wasClicked()) {
            removeNextPageButton_.reset();
            removePage_ += 1;
            clampRemovePage();
            return;
        }

        sf::Vector2i pixelPosition;

        if (!readLeftClickPosition(event, pixelPosition)) {
            return;
        }

        const sf::Vector2f mousePos =
            window.mapPixelToCoords(pixelPosition);

        int deckIndex = -1;

        if (shopView_.handleRemoveCardClick(
                mousePos,
                static_cast<int>(context.runState.masterDeck.size()),
                removePage_,
                deckIndex
            )) {
            removeCardByDeckIndex(deckIndex);
            return;
        }

        return;
    }

    removeCardButton_.handleEvent(event, window);
    leaveButton_.handleEvent(event, window);

    if (removeCardButton_.wasClicked()) {
        removeCardButton_.reset();
        startRemoveCard();
        return;
    }

    if (leaveButton_.wasClicked()) {
        leaveButton_.reset();
        leaveShop();
        return;
    }

    sf::Vector2i pixelPosition;

    if (!readLeftClickPosition(event, pixelPosition)) {
        return;
    }

    const sf::Vector2f mousePos =
        window.mapPixelToCoords(pixelPosition);

    int clickedIndex = -1;

    if (shopView_.handleCardClick(
            mousePos,
            static_cast<int>(cardOffers_.size()),
            clickedIndex
        )) {
        buyCard(clickedIndex);
        return;
    }
}





void ShopScene::update(float dt)
{
    if (removeCardScene_) {
        removeCardScene_->update(dt);

        if (removeCardScene_->isFinished()) {
            finishRemoveCardFromScene();
        }
    }
}


void ShopScene::draw(sf::RenderWindow& window)
{
    const sf::Font& font = context.resources.getFont("zh-R");

    shopView_.layoutButtons(
        mapIconButton_,
        removeCardButton_,
        leaveButton_,
        cancelRemoveButton_,
        removePrevPageButton_,
        removeNextPageButton_,
        window
    );

    const std::vector<ShopCardViewData> shopCards =
        buildShopCardViewData();

    shopView_.drawMain(
        window,
        context,
        font,
        shopCards,
        message_,
        getRemoveCost(),
        mapIconButton_,
        removeCardButton_,
        leaveButton_
    );

    if (removingCard_ && removeCardScene_) {
        removeCardScene_->draw(window);
        return;
    }
}


SceneTransition ShopScene::getTransition() const
{
    return transition_;
}

void ShopScene::buyCard(int index)
{
    if (index < 0 ||
        index >= static_cast<int>(cardOffers_.size())) {
        return;
    }

    if (sold_[index]) {
        message_ = "This card has already been sold.";
        return;
    }

    if (context.runState.gold < SHOP_CARD_COST) {
        message_ = "Not enough gold.";
        return;
    }

    context.runState.gold -= SHOP_CARD_COST;

    const CardId cardId = cardOffers_[index];

    CardInstance temp;
    temp.instanceId = context.runState.nextCardInstanceId++;
    temp.cardId = cardId;

    context.runState.masterDeck.push_back(temp);


    sold_[index] = true;
    message_ = "Card purchased.";
}

void ShopScene::leaveShop()
{
    mapSystem_.completeSelectedNode(context.runState);

    if (mapSystem_.isRouteFinished(context.runState)) {
        transition_.target = SceneType::End;
        transition_.battleResult = BattleResult::Victory;
    } else {
        transition_.target = SceneType::Map;
    }
}

int ShopScene::getRemoveCost() const
{
    return SHOP_REMOVE_BASE_COST * (shopRemoveCount_ + 1);
}

void ShopScene::startRemoveCard()
{

    if (context.runState.masterDeck.empty()) {
        message_ = "There are no cards to remove.";
        return;
    }

    const int cost = getRemoveCost();

    if (context.runState.gold < cost) {
        std::ostringstream text;
        text << "Not enough gold. Need "
             << cost
             << " gold.";

        message_ = text.str();
        return;
    }

    context.runState.gold -= cost;
    context.runState.pendingRemoveCardCount = 1;
    context.runState.pendingEventEffects.clear();

    pendingShopRemoveCost_ = cost;

    removeCardScene_ = std::make_unique<CardRemoveScene>(
        context,
        CardRemoveSceneMode::Embedded
    );

    removingCard_ = true;
    removePage_ = 0;
    message_.clear();


}

void ShopScene::removeCardByDeckIndex(int deckIndex)
{
    if (
        deckIndex < 0 ||
        deckIndex >= static_cast<int>(context.runState.masterDeck.size())
    ) {
        return;
    }

    const int cost = getRemoveCost();

    if (context.runState.gold < cost) {
        std::ostringstream text;
        text << "Not enough gold. Need "
             << cost
             << " gold.";

        message_ = text.str();
        removingCard_ = false;
        return;
    }

    std::string removedName = "a card";

    const CardId cardId =
        context.runState.masterDeck[deckIndex].cardId;

    if (context.cards.exists(cardId)) {
        removedName = context.cards.get(cardId).name;
    }

    context.runState.gold -= cost;

    context.runState.masterDeck.erase(
        context.runState.masterDeck.begin() + deckIndex
    );

    shopRemoveCount_ += 1;
    removingCard_ = false;

    clampRemovePage();

    std::ostringstream text;
    text << "Removed "
         << removedName
         << " for "
         << cost
         << " gold.";

    if (!context.runState.masterDeck.empty()) {
        text << " Next removal costs "
             << getRemoveCost()
             << " gold.";
    }

    message_ = text.str();
}

int ShopScene::getRemoveCardsPerPage() const
{
    return shopView_.getRemoveCardsPerPage();
}


int ShopScene::getRemovePageCount() const
{
    const int deckSize =
        static_cast<int>(context.runState.masterDeck.size());

    if (deckSize <= 0) {
        return 1;
    }

    const int cardsPerPage = getRemoveCardsPerPage();

    return (deckSize + cardsPerPage - 1) / cardsPerPage;
}

void ShopScene::clampRemovePage()
{
    const int pageCount = getRemovePageCount();

    if (removePage_ < 0) {
        removePage_ = 0;
    }

    if (removePage_ >= pageCount) {
        removePage_ = pageCount - 1;
    }
}

void ShopScene::resetTransition()
{
    transition_ = SceneTransition{};
}

const sf::Texture& ShopScene::getCardTemplateTexture(CardType type) const
{
    switch (type) {
        case CardType::Attack:
            return context.resources.getTexture("Attack");

        case CardType::Skill:
            return context.resources.getTexture("Skill");

        case CardType::Curse:
            return context.resources.getTexture("Curse");
    }

    return context.resources.getTexture("Attack");
}

const sf::Texture* ShopScene::getCardArtTexture(
    const CardDef& cardDef
) const
{
    if (
        cardDef.textureId.empty() ||
        !context.resources.hasTexture(cardDef.textureId)
    ) {
        return nullptr;
    }

    return &context.resources.getTexture(cardDef.textureId);
}

CardRenderTextures ShopScene::getCardRenderTextures(
    const CardDef& cardDef
) const
{
    CardRenderTextures textures;

    textures.templateTexture =
        &getCardTemplateTexture(cardDef.type);

    textures.artTexture =
        getCardArtTexture(cardDef);

    return textures;
}

std::vector<ShopCardViewData> ShopScene::buildShopCardViewData() const
{
    std::vector<ShopCardViewData> result;
    result.reserve(cardOffers_.size());

    for (int i = 0; i < static_cast<int>(cardOffers_.size()); ++i) {
        const CardId cardId = cardOffers_[i];

        if (!context.cards.exists(cardId)) {
            continue;
        }

        const CardDef& def = context.cards.get(cardId);

        ShopCardViewData data;
        data.cardId = cardId;
        data.cardDef = &def;
        data.textures = getCardRenderTextures(def);
        data.sold = sold_[i];

        result.push_back(data);
    }

    return result;
}

void ShopScene::finishRemoveCardFromScene()
{
    const bool removed = context.runState.pendingRemoveCardCount <= 0;

    removeCardScene_.reset();
    removingCard_ = false;
    context.runState.pendingEventEffects.clear();

    if (removed) {
        shopRemoveCount_ += 1;

        std::ostringstream text;
        text << "Removed a card for "
             << pendingShopRemoveCost_
             << " gold.";

        if (!context.runState.masterDeck.empty()) {
            text << " Next removal costs "
                 << getRemoveCost()
                 << " gold.";
        }

        message_ = text.str();
    } else {
        context.runState.gold += pendingShopRemoveCost_;
        context.runState.pendingRemoveCardCount = 0;
        message_ = "Card removal cancelled.";
    }

    pendingShopRemoveCost_ = 0;
}
