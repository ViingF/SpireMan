#pragma once
#include "model/Enemy.hpp"
#include "model/Player.hpp"

class EnemyAISystem
{
public:
    EnemyIntent chooseIntent(const Enemy& enemy, int turnIndex) const;//������ͼ
    void applyIntent(Enemy& enemy, Player& player) const;//ִ����ͼ
};
